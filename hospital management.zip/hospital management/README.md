# Hospital Management System (Desktop)
Python + Tkinter + SQLite. Koi extra install nahi chahiye.

## Chalane ka tareeqa
1. Python 3 install karo (python.org, "Add to PATH" tick karo).
2. `python hms.py`  (Windows par double-click bhi chal jata hai)

Data `hms.db` file mein save hota hai (backup ke liye is file ki copy rakho).

## Features
Medicines/stock, purchase, sale, lab, OPD, employees + salary, expenses,
aur Dashboard par kisi bhi date range ka profit/loss report.
