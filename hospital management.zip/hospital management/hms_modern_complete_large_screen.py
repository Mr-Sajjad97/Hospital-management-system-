import sqlite3, customtkinter as ctk, os, tempfile, shutil, hashlib, secrets, hmac
from pathlib import Path
from tkinter import ttk, messagebox
from datetime import date, timedelta, datetime

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "hms.db"
BACKUP_DIR = APP_DIR / "backups"

def backup_database_daily(force=False):
    """Keep one safe SQLite backup per calendar day, without overwriting old backups."""
    if not DB_PATH.exists() or DB_PATH.stat().st_size == 0:
        return
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    target = BACKUP_DIR / f"hms_{date.today().isoformat()}.db"
    if target.exists() and not force:
        return
    try:
        source = sqlite3.connect(str(DB_PATH))
        destination = sqlite3.connect(str(target))
        with destination:
            source.backup(destination)
        destination.close()
        source.close()
    except Exception as exc:
        try:
            if target.exists(): target.unlink()
        except OSError:
            pass
        print(f"Daily database backup warning: {exc}")

backup_database_daily()

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

db = sqlite3.connect(str(DB_PATH))
db.execute("PRAGMA foreign_keys = ON")
db.executescript("""
CREATE TABLE IF NOT EXISTS medicines(id INTEGER PRIMARY KEY, name, company, batch, expiry, buy_price REAL, sale_price REAL, qty INTEGER);
CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY, date, medicine_id INTEGER, qty INTEGER, buy_price REAL, supplier);
CREATE TABLE IF NOT EXISTS purchase_payments(id INTEGER PRIMARY KEY, invoice_no TEXT, date TEXT, supplier TEXT, amount REAL NOT NULL, method TEXT DEFAULT 'Cash', note TEXT);
CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY, date, medicine_id INTEGER, qty INTEGER, price REAL, cost REAL, customer TEXT DEFAULT 'Walk-in Customer', bill_no TEXT);
CREATE TABLE IF NOT EXISTS lab(id INTEGER PRIMARY KEY, date, patient, test, fee REAL);
CREATE TABLE IF NOT EXISTS opd(id INTEGER PRIMARY KEY, date, patient, doctor, fee REAL);
CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY, name, role, salary REAL, phone);
CREATE TABLE IF NOT EXISTS salaries(id INTEGER PRIMARY KEY, date, employee_id INTEGER, amount REAL);
CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY, date, category, amount REAL, note);
CREATE TABLE IF NOT EXISTS app_auth(id INTEGER PRIMARY KEY CHECK(id=1), password_salt TEXT NOT NULL, password_hash TEXT NOT NULL, recovery_salt TEXT NOT NULL, recovery_hash TEXT NOT NULL);
""")
# Upgrade existing databases without deleting any existing records.
_sales_columns = {row[1] for row in db.execute("PRAGMA table_info(sales)").fetchall()}
if "customer" not in _sales_columns:
    db.execute("ALTER TABLE sales ADD COLUMN customer TEXT DEFAULT 'Walk-in Customer'")
if "bill_no" not in _sales_columns:
    db.execute("ALTER TABLE sales ADD COLUMN bill_no TEXT")
_purchase_columns = {row[1] for row in db.execute("PRAGMA table_info(purchases)").fetchall()}
if "invoice_no" not in _purchase_columns:
    db.execute("ALTER TABLE purchases ADD COLUMN invoice_no TEXT")
# Give historical purchase rows stable invoice references; this does not change stock or balances.
for _row in db.execute("SELECT id FROM purchases WHERE invoice_no IS NULL OR invoice_no='' ").fetchall():
    db.execute("UPDATE purchases SET invoice_no=? WHERE id=?", (f"LEGACY-{_row[0]:06d}", _row[0]))
db.commit()
# If this is the first run and the database did not exist before startup, create
# the first backup after the schema has been initialized.
backup_database_daily()

def q(sql, args=()):
    cur = db.execute(sql, args); db.commit(); return cur.fetchall()

def meds():
    return [f"{r[0]} - {r[1]}" for r in q("SELECT id,name FROM medicines ORDER BY name")]

class Sidebar(ctk.CTkFrame):
    def __init__(self, master, on_select):
        super().__init__(master, width=200, corner_radius=0, fg_color="#1a1a2e")
        self.pack_propagate(False)
        self.on_select = on_select
        self.buttons = {}
        self.active = None
        ctk.CTkLabel(self, text="✚", font=("Segoe UI", 36), text_color="#4fc3f7").pack(pady=(20, 0))
        ctk.CTkLabel(self, text="HMS", font=("Segoe UI", 18, "bold"), text_color="white").pack()
        ctk.CTkLabel(self, text="Hospital Management", font=("Segoe UI", 9), text_color="#888").pack(pady=(0, 20))
        ctk.CTkFrame(self, height=1, fg_color="#333").pack(fill="x", padx=16, pady=4)
        pages = [("📊", "Dashboard"),("💊", "Medicines"),("🛒", "Purchase"),("🧾", "Sale"),("🔬", "Lab"),("🏥", "OPD"),("👤", "Employees"),("💸", "Expenses")]
        for icon, name in pages:
            btn = ctk.CTkButton(self, text=f"  {icon}  {name}", anchor="w", font=("Segoe UI", 13), height=42,
                fg_color="transparent", hover_color="#16213e", text_color="#ccc", corner_radius=8,
                command=lambda n=name: self.select(n))
            btn.pack(fill="x", padx=10, pady=2)
            self.buttons[name] = btn
        ctk.CTkFrame(self, height=1, fg_color="#333").pack(fill="x", padx=16, pady=10, side="bottom")
        self.mode_btn = ctk.CTkButton(self, text="☀  Light Mode", font=("Segoe UI", 11),
            fg_color="#16213e", hover_color="#0f3460", height=36, command=self.toggle_mode)
        self.mode_btn.pack(side="bottom", fill="x", padx=10, pady=8)
        # Initial page selection is triggered by App after all widgets are created.

    def select(self, name):
        if self.active:
            self.buttons[self.active].configure(fg_color="transparent", text_color="#ccc")
        self.active = name
        self.buttons[name].configure(fg_color="#0f3460", text_color="white")
        self.on_select(name)

    def toggle_mode(self):
        if ctk.get_appearance_mode() == "Dark":
            ctk.set_appearance_mode("light")
            self.mode_btn.configure(text="🌙  Dark Mode")
        else:
            ctk.set_appearance_mode("dark")
            self.mode_btn.configure(text="☀  Light Mode")

def make_tree(parent, heads):
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("HMS.Treeview", background="#1e1e2e", fieldbackground="#1e1e2e",
        foreground="white", rowheight=28, font=("Segoe UI", 10))
    style.configure("HMS.Treeview.Heading", background="#0f3460", foreground="#4fc3f7",
        font=("Segoe UI", 10, "bold"), relief="flat")
    style.map("HMS.Treeview", background=[("selected", "#0f3460")], foreground=[("selected", "white")])
    tv = ttk.Treeview(parent, columns=heads, show="headings", style="HMS.Treeview")
    for h in heads:
        tv.heading(h, text=h)
        tv.column(h, width=max(80, 600 // len(heads)), anchor="center")
    tv.tag_configure("low", background="#3b0d0d")
    tv.tag_configure("alt", background="#16213e")
    sb = ttk.Scrollbar(parent, orient="vertical", command=tv.yview)
    tv.configure(yscrollcommand=sb.set)
    return tv, sb

class CrudPage(ctk.CTkFrame):
    def __init__(self, master, table, fields, select, heads, hook=None, dated=True, extra=None):
        super().__init__(master, corner_radius=0, fg_color="transparent")
        self.table, self.fields, self.select = table, fields, select
        self.hook, self.dated = hook, dated
        self.w = {}
        card = ctk.CTkFrame(self, corner_radius=12, fg_color="#16213e")
        card.pack(fill="x", padx=20, pady=(16, 8))
        ctk.CTkLabel(card, text="➕  New Entry", font=("Segoe UI", 13, "bold"), text_color="#4fc3f7").grid(
            row=0, column=0, columnspan=8, sticky="w", padx=16, pady=(12, 4))
        for i, (lab, col, kind) in enumerate(fields):
            ctk.CTkLabel(card, text=lab, font=("Segoe UI", 11), text_color="#aaa").grid(
                row=1+(i//4)*2, column=i%4, sticky="w", padx=12, pady=(6,0))
            if kind == "med":
                e = ctk.CTkComboBox(card, width=160, values=meds())
                e.set("")
                self.w_med = e
            else:
                e = ctk.CTkEntry(card, width=160, placeholder_text=lab)
            e.grid(row=2+(i//4)*2, column=i%4, padx=12, pady=(0,10))
            self.w[col] = (e, kind)
        btn_row = ctk.CTkFrame(card, fg_color="transparent")
        btn_row.grid(row=100, column=0, columnspan=8, sticky="w", padx=12, pady=(0,12))
        ctk.CTkButton(btn_row, text=("Sell & Generate Bill" if table == "sales" else "✚  Add"), width=160 if table == "sales" else 110, height=36, fg_color="#16a34a", hover_color="#15803d",
            font=("Segoe UI", 12, "bold"), command=(lambda: self.add(generate_bill=True) if table == "sales" else self.add())).pack(side="left", padx=4)
        if table == "sales":
            ctk.CTkButton(btn_row, text="Sell Without Bill", width=145, height=36, fg_color="#0f3460", hover_color="#16213e",
                font=("Segoe UI", 12, "bold"), command=lambda: self.add(generate_bill=False)).pack(side="left", padx=4)
        ctk.CTkButton(btn_row, text="🗑  Delete", width=130, height=36, fg_color="#dc2626", hover_color="#b91c1c",
            font=("Segoe UI", 12, "bold"), command=self.delete).pack(side="left", padx=4)
        for text, fn in (extra or []):
            ctk.CTkButton(btn_row, text=text, width=150, height=36, fg_color="#0f3460", hover_color="#16213e",
                command=lambda f=fn: f(self.selected())).pack(side="left", padx=4)
        toolbar = ctk.CTkFrame(self, fg_color="transparent")
        toolbar.pack(fill="x", padx=20, pady=(0,8))
        self.search_entry = ctk.CTkEntry(toolbar, width=240, placeholder_text="Search records...")
        self.search_entry.pack(side="left", padx=(0,6))
        ctk.CTkButton(toolbar, text="Search", width=75, command=self.refresh).pack(side="left", padx=3)
        ctk.CTkButton(toolbar, text="Clear", width=65, fg_color="#374151", command=self.clear_search).pack(side="left", padx=3)
        self.date_filter = "All Time"
        if self.table in ("purchases", "sales", "lab", "opd", "expenses"):
            for label in ("Today", "This Week", "This Month", "All Time"):
                ctk.CTkButton(toolbar, text=label, width=82, fg_color="#0f3460",
                    command=lambda value=label: self.set_date_filter(value)).pack(side="left", padx=2)
        tree_frame = ctk.CTkFrame(self, corner_radius=12, fg_color="#16213e")
        tree_frame.pack(fill="both", expand=True, padx=20, pady=(0,16))
        self.tree, sb = make_tree(tree_frame, heads)
        self.tree.pack(side="left", fill="both", expand=True, padx=(8,0), pady=8)
        sb.pack(side="right", fill="y", pady=8, padx=(0,4))
        self.refresh()

    def selected(self):
        s = self.tree.selection()
        return self.tree.item(s[0])["values"] if s else None

    def clear_search(self):
        self.search_entry.delete(0, "end")
        self.refresh()

    def set_date_filter(self, value):
        self.date_filter = value
        self.refresh()

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        rows = q(self.select)
        today = date.today()
        if self.table in ("purchases", "sales", "lab", "opd", "expenses") and self.date_filter != "All Time":
            if self.date_filter == "Today": start = today
            elif self.date_filter == "This Week": start = today - timedelta(days=today.weekday())
            else: start = today.replace(day=1)
            rows = [r for r in rows if len(r) > 1 and str(start) <= str(r[1]) <= str(today)]
        term = self.search_entry.get().strip().casefold() if hasattr(self, "search_entry") else ""
        if term:
            rows = [r for r in rows if term in " ".join(str(v) for v in r if v is not None).casefold()]
        for i, r in enumerate(rows):
            tag = "low" if self.table == "medicines" and r[-1] < 10 else "alt" if i%2 else ""
            self.tree.insert("", "end", values=r, tags=(tag,))

    def add(self, generate_bill=True):
        vals = {}
        try:
            for col, (e, kind) in self.w.items():
                v = (e.get() if hasattr(e,'get') else "").strip()
                optional = (self.table == "sales" and col == "customer") or (self.table == "purchases" and col in ("invoice_no", "paid_now"))
                if not v and not optional:
                    raise ValueError("Please complete all required fields.")
                if self.table == "purchases" and col == "paid_now" and not v:
                    vals[col] = 0.0
                else:
                    vals[col] = float(v) if kind=="num" else int(v.split(" - ")[0]) if kind=="med" else v
            paid_now = 0.0
            if self.table == "sales":
                vals["customer"] = vals.pop("customer", "Walk-in Customer") or "Walk-in Customer"
                vals["bill_no"] = None
            if self.table == "purchases":
                paid_now = float(vals.pop("paid_now", 0) or 0)
                if int(vals.get("qty", 0)) <= 0 or float(vals.get("buy_price", 0)) < 0:
                    raise ValueError("Quantity must be positive and purchase price cannot be negative.")
                invoice_no = (vals.get("invoice_no") or "").strip()
                if not invoice_no:
                    invoice_no = f"PUR-{date.today().strftime('%Y%m%d')}-{datetime.now().strftime('%H%M%S')}"
                vals["invoice_no"] = invoice_no
                if paid_now < 0: raise ValueError("Paid amount cannot be negative.")
            if self.hook: self.hook(vals)
            if self.dated: vals["date"] = str(date.today())
            q(f"INSERT INTO {self.table}({','.join(vals)}) VALUES({','.join('?'*len(vals))})", list(vals.values()))
            if self.table == "purchases" and paid_now > 0:
                q("INSERT INTO purchase_payments(invoice_no,date,supplier,amount,method,note) VALUES(?,?,?,?,?,?)",
                  (invoice_no, str(date.today()), vals.get("supplier", ""), paid_now, "Cash", "Initial payment"))
            if self.table == "sales":
                sale_id = q("SELECT last_insert_rowid()")[0][0]
                bill_no = f"INV-{date.today().strftime('%Y%m%d')}-{sale_id:04d}" if generate_bill else None
                if bill_no:
                    q("UPDATE sales SET bill_no=? WHERE id=?", (bill_no, sale_id))
                    sale = q("SELECT s.date, s.customer, m.name, s.qty, s.price, s.qty*s.price FROM sales s JOIN medicines m ON m.id=s.medicine_id WHERE s.id=?", (sale_id,))[0]
                    receipt = ("HOSPITAL / PHARMACY\nSALES RECEIPT\n" + "="*30 +
                        f"\nBill No: {bill_no}\nDate: {sale[0]}\nCustomer: {sale[1]}\n" + "-"*30 +
                        f"\nMedicine: {sale[2]}\nQuantity: {sale[3]}\nUnit Price: {sale[4]:,.2f}\nTOTAL: {sale[5]:,.2f}\n" + "="*30 + "\nThank you!")
                    self.show_receipt(receipt)
        except (ValueError, IndexError) as ex:
            msg = str(ex)
            return messagebox.showerror("Error", msg if ("Please" in msg or "stock" in msg.lower() or "negative" in msg.lower()) else "Please enter valid numbers and select a valid medicine.")
        for e, _ in self.w.values():
            if hasattr(e,'delete'): e.delete(0,"end")
            elif hasattr(e,'set'): e.set("")
        self.refresh()

    def show_receipt(self, receipt):
        win = ctk.CTkToplevel(self)
        win.title("Sales Bill")
        win.geometry("440x480")
        win.transient(self.winfo_toplevel())
        ctk.CTkLabel(win, text="Bill Generated Successfully", font=("Segoe UI", 16, "bold")).pack(pady=(16, 8))
        box = ctk.CTkTextbox(win, width=390, height=340, font=("Consolas", 13))
        box.pack(padx=16, pady=8, fill="both", expand=True)
        box.insert("1.0", receipt)
        box.configure(state="disabled")
        actions = ctk.CTkFrame(win, fg_color="transparent")
        actions.pack(pady=(4, 14))
        ctk.CTkButton(actions, text="Print Bill", command=lambda: self.print_receipt(receipt)).pack(side="left", padx=5)
        ctk.CTkButton(actions, text="Close", command=win.destroy).pack(side="left", padx=5)

    def print_receipt(self, receipt):
        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", prefix="hms_bill_", delete=False, encoding="utf-8") as f:
                f.write(receipt)
                path = f.name
            os.startfile(path, "print")
        except Exception as ex:
            messagebox.showerror("Print Error", f"Could not send the bill to the printer.\n{ex}")

    def delete(self):
        r = self.selected()
        if r and messagebox.askyesno("Delete", "Are you sure you want to delete this record?"):
            q(f"DELETE FROM {self.table} WHERE id=?", (r[0],))
            self.refresh()

def purchase_hook(v):
    v["qty"] = int(v["qty"])
    q("UPDATE medicines SET qty=qty+?, buy_price=? WHERE id=?", (v["qty"], v["buy_price"], v["medicine_id"]))

def sale_hook(v):
    v["qty"] = int(v["qty"])
    m = q("SELECT qty,sale_price,buy_price FROM medicines WHERE id=?", (v["medicine_id"],))[0]
    if v["qty"] > m[0]: raise ValueError(f"Insufficient stock. Only {m[0]} unit(s) remaining.")
    v["price"], v["cost"] = m[1], m[2]
    q("UPDATE medicines SET qty=qty-? WHERE id=?", (v["qty"], v["medicine_id"]))

def show_supplier_balances(_row=None):
    win = ctk.CTkToplevel()
    win.title("Supplier Balances")
    win.geometry("850x480")
    ctk.CTkLabel(win, text="Supplier Invoice Balances", font=("Segoe UI", 18, "bold")).pack(pady=12)
    frame = ctk.CTkFrame(win); frame.pack(fill="both", expand=True, padx=12, pady=12)
    tree, sb = make_tree(frame, ("Invoice No.", "Supplier", "First Date", "Total Bill", "Paid", "Due"))
    tree.pack(side="left", fill="both", expand=True); sb.pack(side="right", fill="y")
    rows = q("""SELECT p.invoice_no, p.supplier, MIN(p.date), SUM(p.qty*p.buy_price),
        COALESCE((SELECT SUM(pp.amount) FROM purchase_payments pp WHERE pp.invoice_no=p.invoice_no),0),
        SUM(p.qty*p.buy_price)-COALESCE((SELECT SUM(pp.amount) FROM purchase_payments pp WHERE pp.invoice_no=p.invoice_no),0)
        FROM purchases p GROUP BY p.invoice_no,p.supplier ORDER BY MIN(p.date) DESC""")
    for r in rows: tree.insert("", "end", values=(r[0],r[1],r[2],f"{r[3]:,.2f}",f"{r[4]:,.2f}",f"{r[5]:,.2f}"))

def record_supplier_payment(_row=None):
    win = ctk.CTkToplevel()
    win.title("Record Supplier Payment")
    win.geometry("420x360")
    fields = {}
    for label, key in (("Invoice Number", "invoice_no"),("Supplier Name", "supplier"),("Amount Paid", "amount"),("Payment Method", "method"),("Note", "note")):
        ctk.CTkLabel(win, text=label).pack(anchor="w", padx=20, pady=(8,0))
        entry = ctk.CTkEntry(win, width=370, placeholder_text=label); entry.pack(padx=20, pady=(0,3)); fields[key]=entry
    fields["method"].insert(0,"Cash")
    def save():
        invoice = fields["invoice_no"].get().strip(); supplier=fields["supplier"].get().strip()
        try: amount=float(fields["amount"].get())
        except ValueError: return messagebox.showerror("Invalid Amount", "Enter a valid payment amount.", parent=win)
        if not invoice or amount <= 0: return messagebox.showerror("Missing Details", "Invoice number and a positive amount are required.", parent=win)
        exists=q("SELECT 1 FROM purchases WHERE invoice_no=?", (invoice,))
        if not exists: return messagebox.showerror("Invoice Not Found", "No purchase invoice was found with that number.", parent=win)
        q("INSERT INTO purchase_payments(invoice_no,date,supplier,amount,method,note) VALUES(?,?,?,?,?,?)", (invoice,str(date.today()),supplier,amount,fields["method"].get().strip() or "Cash",fields["note"].get().strip()))
        messagebox.showinfo("Saved", "Supplier payment recorded.", parent=win); win.destroy()
    ctk.CTkButton(win, text="Save Payment", command=save).pack(pady=14)

def show_salary_history(row):
    if not row:
        return messagebox.showwarning("Select Employee", "Select an employee first.")
    win=ctk.CTkToplevel(); win.title(f"Salary History - {row[1]}"); win.geometry("650x400")
    ctk.CTkLabel(win,text=f"Salary Payment History: {row[1]}",font=("Segoe UI",16,"bold")).pack(pady=12)
    frame=ctk.CTkFrame(win); frame.pack(fill="both",expand=True,padx=12,pady=12)
    tree,sb=make_tree(frame,("Payment ID","Payment Date","Salary Month","Amount")); tree.pack(side="left",fill="both",expand=True); sb.pack(side="right",fill="y")
    for r in q("SELECT id,date,amount FROM salaries WHERE employee_id=? ORDER BY date DESC,id DESC",(row[0],)):
        try: month = datetime.strptime(r[1], "%Y-%m-%d").strftime("%B %Y")
        except (ValueError, TypeError): month = "Unknown"
        tree.insert("","end",values=(r[0],r[1],month,f"{r[2]:,.2f}"))


def _password_hash(password, salt_hex=None):
    salt = bytes.fromhex(salt_hex) if salt_hex else secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 310_000)
    return salt.hex(), digest.hex()

def _password_is_strong(password):
    return (len(password) >= 12 and any(c.islower() for c in password)
            and any(c.isupper() for c in password) and any(c.isdigit() for c in password)
            and any(not c.isalnum() for c in password))

class AuthWindow(ctk.CTk):
    """Single-user local sign-in with one-time recovery key."""
    def __init__(self):
        super().__init__()
        self.authenticated = False
        self.title("HMS - Secure Sign In")
        self.geometry("430x430")
        self.resizable(False, False)
        self.configure(fg_color="#0d1117")
        ctk.CTkLabel(self, text="HMS", font=("Segoe UI", 30, "bold"), text_color="#4fc3f7").pack(pady=(28,4))
        ctk.CTkLabel(self, text="Hospital Management System", text_color="#aaa").pack(pady=(0,18))
        self.heading = ctk.CTkLabel(self, text="", font=("Segoe UI", 17, "bold"))
        self.heading.pack(pady=6)
        self.password = ctk.CTkEntry(self, width=320, placeholder_text="Password", show="*")
        self.password.pack(pady=8)
        self.confirm = ctk.CTkEntry(self, width=320, placeholder_text="Confirm password", show="*")
        self.confirm.pack(pady=8)
        self.action = ctk.CTkButton(self, width=320, height=38, command=self.submit)
        self.action.pack(pady=(14,6))
        self.forgot = ctk.CTkButton(self, text="Forgot Password / Reset", width=320, fg_color="transparent",
                                    border_width=1, command=self.reset_password)
        self.forgot.pack(pady=5)
        self._refresh_mode()
        self.password.bind("<Return>", lambda _e: self.submit())

    def _refresh_mode(self):
        exists = db.execute("SELECT 1 FROM app_auth WHERE id=1").fetchone()
        self.setup_mode = not bool(exists)
        self.heading.configure(text="Create Admin Password" if self.setup_mode else "Sign In")
        self.confirm.pack(pady=8) if self.setup_mode else self.confirm.pack_forget()
        self.action.configure(text="Create Password" if self.setup_mode else "Sign In")
        self.forgot.pack_forget() if self.setup_mode else self.forgot.pack(pady=5)

    def submit(self):
        password = self.password.get()
        if self.setup_mode:
            if not _password_is_strong(password):
                return messagebox.showerror("Weak Password", "Use at least 12 characters, including uppercase, lowercase, a number, and a symbol.", parent=self)
            if password != self.confirm.get():
                return messagebox.showerror("Password Mismatch", "The passwords do not match.", parent=self)
            recovery = secrets.token_urlsafe(18)
            ps, ph = _password_hash(password)
            rs, rh = _password_hash(recovery)
            db.execute("INSERT INTO app_auth(id,password_salt,password_hash,recovery_salt,recovery_hash) VALUES(1,?,?,?,?)", (ps,ph,rs,rh))
            db.commit()
            messagebox.showwarning("Save Your Recovery Key",
                "Your password recovery key is shown below. Save it somewhere safe; it is shown only once.\n\n" + recovery, parent=self)
            self.authenticated = True
            self.destroy()
            return
        row = db.execute("SELECT password_salt,password_hash FROM app_auth WHERE id=1").fetchone()
        if row:
            _, digest = _password_hash(password, row[0])
            if hmac.compare_digest(digest, row[1]):
                self.authenticated = True
                self.destroy()
                return
        messagebox.showerror("Sign In Failed", "Incorrect password.", parent=self)

    def reset_password(self):
        win = ctk.CTkToplevel(self); win.title("Reset Password"); win.geometry("400x330"); win.transient(self); win.grab_set()
        recovery = ctk.CTkEntry(win, width=330, placeholder_text="Recovery key")
        recovery.pack(pady=(22,8))
        newpass = ctk.CTkEntry(win, width=330, placeholder_text="New strong password", show="*")
        newpass.pack(pady=8)
        confirm = ctk.CTkEntry(win, width=330, placeholder_text="Confirm new password", show="*")
        confirm.pack(pady=8)
        def save():
            row = db.execute("SELECT recovery_salt,recovery_hash FROM app_auth WHERE id=1").fetchone()
            if not row: return messagebox.showerror("Unavailable", "No recovery key is configured.", parent=win)
            _, digest = _password_hash(recovery.get().strip(), row[0])
            if not hmac.compare_digest(digest, row[1]):
                return messagebox.showerror("Invalid Key", "Recovery key is incorrect.", parent=win)
            pw = newpass.get()
            if not _password_is_strong(pw):
                return messagebox.showerror("Weak Password", "Use at least 12 characters, including uppercase, lowercase, a number, and a symbol.", parent=win)
            if pw != confirm.get(): return messagebox.showerror("Password Mismatch", "The passwords do not match.", parent=win)
            salt, digest = _password_hash(pw)
            db.execute("UPDATE app_auth SET password_salt=?,password_hash=? WHERE id=1", (salt,digest)); db.commit()
            messagebox.showinfo("Password Reset", "Password updated successfully.", parent=win)
            win.destroy(); self.password.delete(0,"end")
        ctk.CTkButton(win, text="Reset Password", command=save).pack(pady=14)


def pay_salary(row):
    if not row:
        messagebox.showwarning("Select Employee", "Please click an employee row in the table first, then click Pay Salary.")
        return
    if messagebox.askyesno("Confirm Salary Payment", f"Record salary payment of {row[3]} to {row[1]}?"):
        q("INSERT INTO salaries(date,employee_id,amount) VALUES(?,?,?)", (str(date.today()), row[0], row[3]))
        messagebox.showinfo("Success", "Salary payment recorded successfully and added to Dashboard expenses.")

class Dashboard(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, corner_radius=0, fg_color="transparent")
        self.val_labels = {}
        self.kpi_val = {}
        self.kpi_lbl = {}
        self._build_header()
        self._build_kpis()
        self._build_breakdown()
        self.preset(-1)

    def _build_header(self):
        hdr = ctk.CTkFrame(self, corner_radius=12, fg_color="#16213e")
        hdr.pack(fill="x", padx=20, pady=(16,8))
        ctk.CTkLabel(hdr, text="📊  Financial Overview", font=("Segoe UI",16,"bold"), text_color="#4fc3f7").pack(side="left", padx=16, pady=14)
        bf = ctk.CTkFrame(hdr, fg_color="transparent")
        bf.pack(side="right", padx=12)
        for t, d in (("Today",0),("This Week",6),("This Month",None),("Year",365),("All Time",-1)):
            ctk.CTkButton(bf, text=t, width=72, height=32, fg_color="#0f3460", hover_color="#16213e",
                command=lambda d=d: self.preset(d)).pack(side="left", padx=3)
        self.entry_from = ctk.CTkEntry(bf, width=100, placeholder_text="From")
        self.entry_from.pack(side="left", padx=4)
        self.entry_to = ctk.CTkEntry(bf, width=100, placeholder_text="To")
        self.entry_to.pack(side="left", padx=4)
        ctk.CTkButton(bf, text="Show", width=72, height=32, fg_color="#16a34a", hover_color="#15803d",
            command=self.show).pack(side="left", padx=4)

    def _build_kpis(self):
        kpi_row = ctk.CTkFrame(self, fg_color="transparent")
        kpi_row.pack(fill="x", padx=20, pady=4)
        for icon, title, key, color in [("💰","Total Income","inc","#16a34a"),("📉","Total Expenses","cost","#ea580c"),("📈","Total Profit","profit","#16a34a"),("📉","Total Loss","loss","#dc2626"),("🛒","Medicine Purchases","pur","#7c3aed")]:
            card = ctk.CTkFrame(kpi_row, corner_radius=12, fg_color="#16213e")
            card.pack(side="left", expand=True, fill="both", padx=6, pady=4)
            ctk.CTkLabel(card, text=icon, font=("Segoe UI",28)).pack(anchor="w", padx=16, pady=(14,0))
            lbl = ctk.CTkLabel(card, text=title, font=("Segoe UI",10), text_color="#888")
            lbl.pack(anchor="w", padx=16)
            val = ctk.CTkLabel(card, text="0", font=("Segoe UI",26,"bold"), text_color=color)
            val.pack(anchor="w", padx=16, pady=(0,14))
            self.kpi_val[key] = val
            self.kpi_lbl[key] = lbl

    def _build_breakdown(self):
        grid = ctk.CTkFrame(self, fg_color="transparent")
        grid.pack(fill="both", expand=True, padx=20, pady=(4,16))
        sections = [
            ("Income Breakdown","#16a34a",["Medical store sale","Lab","OPD fees"]),
            ("Expense Breakdown","#ea580c",["Cost of Medicines Sold","Salaries","Expenses"]),
            ("Stock & Staff","#4fc3f7",["Medicine Types","Total Units","Stock Value","Low Stock (<10)","Total employees","Monthly Salary Total"]),
        ]
        for title, color, keys in sections:
            panel = ctk.CTkFrame(grid, corner_radius=12, fg_color="#16213e")
            panel.pack(side="left", expand=True, fill="both", padx=6, anchor="n")
            ctk.CTkLabel(panel, text=title, font=("Segoe UI",12,"bold"), text_color=color).pack(anchor="w", padx=14, pady=(12,6))
            ctk.CTkFrame(panel, height=1, fg_color="#333").pack(fill="x", padx=14, pady=2)
            for name in keys:
                row = ctk.CTkFrame(panel, fg_color="transparent")
                row.pack(fill="x", padx=14, pady=5)
                ctk.CTkLabel(row, text=name, font=("Segoe UI",11), text_color="#aaa").pack(side="left")
                lbl = ctk.CTkLabel(row, text="0", font=("Segoe UI",11,"bold"), text_color="white")
                lbl.pack(side="right")
                self.val_labels[name] = lbl

    def preset(self, days):
        end = date.today()
        if days == -1:
            start = "2000-01-01"
        elif days is None:
            start = end.replace(day=1)
        else:
            start = end - timedelta(days=days)
        self.entry_from.delete(0,"end"); self.entry_from.insert(0,str(start))
        self.entry_to.delete(0,"end"); self.entry_to.insert(0,str(end))
        self.show()

    def show(self):
        a, b = self.entry_from.get(), self.entry_to.get()
        s = lambda sql: q(sql+" AND date BETWEEN ? AND ?", (a,b))[0][0] or 0
        sale=s("SELECT SUM(qty*price) FROM sales WHERE 1=1"); cogs=s("SELECT SUM(qty*cost) FROM sales WHERE 1=1")
        purch=s("SELECT SUM(qty*buy_price) FROM purchases WHERE 1=1")
        lab,opd=s("SELECT SUM(fee) FROM lab WHERE 1=1"),s("SELECT SUM(fee) FROM opd WHERE 1=1")
        sal,exp=s("SELECT SUM(amount) FROM salaries WHERE 1=1"),s("SELECT SUM(amount) FROM expenses WHERE 1=1")
        income,cost=sale+lab+opd,cogs+sal+exp; profit=income-cost
        stock=q("SELECT COUNT(*),SUM(qty),SUM(qty*buy_price) FROM medicines")[0]
        low=q("SELECT COUNT(*) FROM medicines WHERE qty<10")[0][0]
        emp=q("SELECT COUNT(*),SUM(salary) FROM employees")[0]
        pc="#16a34a" if profit>=0 else "#dc2626"
        self.kpi_val["inc"].configure(text=f"{income:,.0f}")
        self.kpi_val["cost"].configure(text=f"{cost:,.0f}")
        self.kpi_val["pur"].configure(text=f"{purch:,.0f}")
        self.kpi_val["profit"].configure(text=f"{max(profit, 0):,.0f}")
        self.kpi_val["loss"].configure(text=f"{max(-profit, 0):,.0f}")
        for k,val in {"Medical store sale":sale,"Lab":lab,"OPD fees":opd,"Cost of Medicines Sold":cogs,"Salaries":sal,"Expenses":exp,"Stock Value":stock[2] or 0,"Monthly Salary Total":emp[1] or 0}.items():
            self.val_labels[k].configure(text=f"{val:,.2f}")
        for k,val in {"Medicine Types":stock[0],"Total Units":stock[1] or 0,"Total employees":emp[0],"Low Stock (<10)":low}.items():
            self.val_labels[k].configure(text=str(val), text_color="#dc2626" if k.startswith("Low") and low else "white")

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("✚ Hospital Management System")
        # Open maximized on Windows so the user gets the full available screen.
        try:
            self.state("zoomed")
        except Exception:
            self.geometry("1360x850")
        self.minsize(800, 550)
        self.resizable(True, True)
        self.bind("<F11>", self._toggle_fullscreen)
        self.sidebar = Sidebar(self, self.show_page)
        self.sidebar.pack(side="left", fill="y")
        self.content = ctk.CTkFrame(self, corner_radius=0, fg_color="#0d1117")
        self.content.pack(side="left", fill="both", expand=True)
        self.title_bar = ctk.CTkLabel(self.content, text="", font=("Segoe UI",18,"bold"), text_color="white", anchor="w")
        self.title_bar.pack(fill="x", padx=24, pady=(18,0))
        self.page_area = ctk.CTkFrame(self.content, corner_radius=0, fg_color="transparent")
        self.page_area.pack(fill="both", expand=True)
        self.pages = {}
        self._build_pages()
        self.protocol("WM_DELETE_WINDOW", self.close_app)
        # Select the initial page only after title_bar and pages exist.
        self.sidebar.select("Dashboard")

    def _build_pages(self):
        self.pages["Dashboard"] = Dashboard(self.page_area)
        self.pages["Medicines"] = CrudPage(self.page_area,"medicines",
            [("Name","name","txt"),("Company","company","txt"),("Batch","batch","txt"),
             ("Expiry","expiry","txt"),("Buy Price","buy_price","num"),("Sale Price","sale_price","num"),("Qty","qty","num")],
            "SELECT * FROM medicines ORDER BY name",("ID","Name","Company","Batch","Expiry","Buy","Sale","Qty"),
            dated=False, hook=lambda v: v.update(qty=int(v["qty"])))
        self.pages["Purchase"] = CrudPage(self.page_area,"purchases",
            [("Invoice No. (same for items in one bill)","invoice_no","txt"),("Medicine","medicine_id","med"),("Qty","qty","num"),("Buy Price","buy_price","num"),("Supplier","supplier","txt"),("Paid Now","paid_now","num")],
            "SELECT p.id,p.date,COALESCE(p.invoice_no,''),m.name,p.qty,p.buy_price,p.supplier,ROUND(p.qty*p.buy_price,2) FROM purchases p JOIN medicines m ON m.id=p.medicine_id ORDER BY p.id DESC",
            ("ID","Date","Invoice","Medicine","Qty","Unit Cost","Supplier","Line Total"), hook=purchase_hook,
            extra=[("Supplier Balances", show_supplier_balances), ("Record Payment", record_supplier_payment)])
        self.pages["Sale"] = CrudPage(self.page_area,"sales",
            [("Medicine","medicine_id","med"),("Qty","qty","num"),("Customer","customer","txt")],
            "SELECT s.id,s.date,COALESCE(s.bill_no,'No Bill'),s.customer,m.name,s.qty,s.price,s.qty*s.price FROM sales s JOIN medicines m ON m.id=s.medicine_id ORDER BY s.id DESC",
            ("ID","Date","Bill No.","Customer","Medicine","Qty","Price","Total"), hook=sale_hook)
        self.pages["Lab"] = CrudPage(self.page_area,"lab",
            [("Patient","patient","txt"),("Test","test","txt"),("Fee","fee","num")],
            "SELECT id,date,patient,test,fee FROM lab ORDER BY id DESC",("ID","Date","Patient","Test","Fee"))
        self.pages["OPD"] = CrudPage(self.page_area,"opd",
            [("Patient","patient","txt"),("Doctor","doctor","txt"),("Fee","fee","num")],
            "SELECT id,date,patient,doctor,fee FROM opd ORDER BY id DESC",("ID","Date","Patient","Doctor","Fee"))
        self.pages["Employees"] = CrudPage(self.page_area,"employees",
            [("Name","name","txt"),("Role","role","txt"),("Salary","salary","num"),("Phone","phone","txt")],
            "SELECT * FROM employees",("ID","Name","Role","Salary","Phone"),
            dated=False, extra=[("💵 Pay Salary", pay_salary), ("Salary History", show_salary_history)])
        self.pages["Expenses"] = CrudPage(self.page_area,"expenses",
            [("Category","category","txt"),("Amount","amount","num"),("Note","note","txt")],
            "SELECT id,date,category,amount,note FROM expenses ORDER BY id DESC",("ID","Date","Category","Amount","Note"))
        for page in self.pages.values():
            page.place(relx=0, rely=0, relwidth=1, relheight=1)

    def _toggle_fullscreen(self, _event=None):
        current = bool(self.attributes("-fullscreen"))
        self.attributes("-fullscreen", not current)
        return "break"

    def close_app(self):
        try:
            db.commit()
            backup_database_daily(force=True)
        finally:
            db.close()
            self.destroy()

    def show_page(self, name):
        icons = {"Dashboard":"📊","Medicines":"💊","Purchase":"🛒","Sale":"🧾","Lab":"🔬","OPD":"🏥","Employees":"👤","Expenses":"💸"}
        self.title_bar.configure(text=f"{icons.get(name,'')}  {name}")
        for n, p in self.pages.items():
            p.lower() if n != name else p.lift()
        page = self.pages[name]
        if isinstance(page, Dashboard): page.show()
        elif hasattr(page, 'refresh'): page.refresh()

if __name__ == "__main__":
    gate = AuthWindow()
    gate.mainloop()
    if gate.authenticated:
        App().mainloop()