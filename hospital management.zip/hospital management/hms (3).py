import sqlite3, tkinter as tk
from tkinter import ttk, messagebox
from datetime import date

db = sqlite3.connect("hms.db")
db.executescript("""
CREATE TABLE IF NOT EXISTS medicines(id INTEGER PRIMARY KEY, name, company, batch, expiry, buy_price REAL, sale_price REAL, qty INTEGER);
CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY, date, medicine_id INTEGER, qty INTEGER, buy_price REAL, supplier);
CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY, date, medicine_id INTEGER, qty INTEGER, price REAL, cost REAL);
CREATE TABLE IF NOT EXISTS lab(id INTEGER PRIMARY KEY, date, patient, test, fee REAL);
CREATE TABLE IF NOT EXISTS opd(id INTEGER PRIMARY KEY, date, patient, doctor, fee REAL);
CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY, name, role, salary REAL, phone);
CREATE TABLE IF NOT EXISTS salaries(id INTEGER PRIMARY KEY, date, employee_id INTEGER, amount REAL);
CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY, date, category, amount REAL, note);
""")

def q(sql, args=()):
    cur = db.execute(sql, args); db.commit(); return cur.fetchall()

def meds():
    return [f"{r[0]} - {r[1]}" for r in q("SELECT id,name FROM medicines ORDER BY name")]

class Crud(ttk.Frame):
    """Generic tab: form on top, list below. fields = (label, column, kind) kind: txt/num/med"""
    def __init__(self, parent, table, fields, select, heads, hook=None, dated=True, extra=None):
        super().__init__(parent)
        self.table, self.fields, self.select, self.hook, self.dated = table, fields, select, hook, dated
        form = ttk.Frame(self); form.pack(fill="x", padx=8, pady=8)
        self.w = {}
        for i, (lab, col, kind) in enumerate(fields):
            ttk.Label(form, text=lab).grid(row=i // 4 * 2, column=i % 4, sticky="w", padx=4)
            if kind == "med":
                e = ttk.Combobox(form, width=22, postcommand=lambda: self.w_med.config(values=meds()))
                self.w_med = e
            else:
                e = ttk.Entry(form, width=22)
            e.grid(row=i // 4 * 2 + 1, column=i % 4, padx=4, pady=2)
            self.w[col] = (e, kind)
        bar = ttk.Frame(self); bar.pack(fill="x", padx=8)
        ttk.Button(bar, text="Add", style="Accent.TButton", command=self.add).pack(side="left", padx=4)
        ttk.Button(bar, text="Delete selected", style="Danger.TButton", command=self.delete).pack(side="left", padx=4)
        for text, fn in (extra or []):
            ttk.Button(bar, text=text, command=lambda f=fn: f(self.selected())).pack(side="left", padx=4)
        self.tree = ttk.Treeview(self, columns=heads, show="headings")
        for h in heads:
            self.tree.heading(h, text=h); self.tree.column(h, width=110)
        self.tree.tag_configure("low", background="#fecaca")
        self.tree.tag_configure("odd", background="#f0fdfa")
        self.tree.pack(fill="both", expand=True, padx=8, pady=8)
        self.refresh()

    def selected(self):
        s = self.tree.selection()
        return self.tree.item(s[0])["values"] if s else None

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(q(self.select)):
            tag = "low" if self.table == "medicines" and r[-1] < 10 else "odd" if i % 2 else ""
            self.tree.insert("", "end", values=r, tags=(tag,))

    def add(self):
        vals = {}
        try:
            for col, (e, kind) in self.w.items():
                v = e.get().strip()
                if not v: raise ValueError("Sab fields bharo")
                vals[col] = float(v) if kind == "num" else int(v.split(" - ")[0]) if kind == "med" else v
            if self.hook: self.hook(vals)
            if self.dated: vals["date"] = str(date.today())
            q(f"INSERT INTO {self.table}({','.join(vals)}) VALUES({','.join('?' * len(vals))})", list(vals.values()))
        except ValueError as ex:
            return messagebox.showerror("Error", str(ex) if "Sab" in str(ex) or "stock" in str(ex).lower() else "Number sahi likho")
        for e, _ in self.w.values(): e.delete(0, "end")
        self.refresh()

    def delete(self):
        r = self.selected()
        if r and messagebox.askyesno("Delete", "Pakka delete karna hai?"):
            q(f"DELETE FROM {self.table} WHERE id=?", (r[0],)); self.refresh()

def purchase_hook(v):
    v["qty"] = int(v["qty"])
    q("UPDATE medicines SET qty=qty+?, buy_price=? WHERE id=?", (v["qty"], v["buy_price"], v["medicine_id"]))

def sale_hook(v):
    v["qty"] = int(v["qty"])
    m = q("SELECT qty,sale_price,buy_price FROM medicines WHERE id=?", (v["medicine_id"],))[0]
    if v["qty"] > m[0]: raise ValueError(f"Stock kam hai, sirf {m[0]} bache hain")
    v["price"], v["cost"] = m[1], m[2]
    q("UPDATE medicines SET qty=qty-? WHERE id=?", (v["qty"], v["medicine_id"]))

def pay_salary(row):
    if row and messagebox.askyesno("Salary", f"{row[1]} ko {row[3]} salary dena hai?"):
        q("INSERT INTO salaries(date,employee_id,amount) VALUES(?,?,?)", (str(date.today()), row[0], row[3]))
        messagebox.showinfo("Done", "Salary likh li gayi")

class Dashboard(tk.Frame):
    BG = "#f1f5f9"
    def __init__(self, parent):
        super().__init__(parent, bg=self.BG)
        self.v = {}
        top = tk.Frame(self, bg=self.BG); top.pack(fill="x", padx=16, pady=(12, 4))
        tk.Label(top, text="Financial Overview", bg=self.BG, fg="#0f172a", font=("Segoe UI", 17, "bold")).pack(side="left")
        ttk.Button(top, text="Show", style="Accent.TButton", command=self.show).pack(side="right")
        self.b, self.a = ttk.Entry(top, width=12), ttk.Entry(top, width=12)
        self.b.pack(side="right", padx=4); tk.Label(top, text="To", bg=self.BG).pack(side="right")
        self.a.pack(side="right", padx=4); tk.Label(top, text="From", bg=self.BG).pack(side="right")
        for t, d in (("Is saal", 365), ("Is mahine", 30), ("Aaj", 0)):
            ttk.Button(top, text=t, command=lambda d=d: self.preset(d)).pack(side="right", padx=3)
        row = tk.Frame(self, bg=self.BG); row.pack(fill="x", padx=10, pady=6)
        self.k = {}
        for key, title, col in (("inc", "TOTAL INCOME", "#16a34a"), ("cost", "TOTAL KHARCHA", "#ea580c"), ("pl", "PROFIT", "#16a34a"), ("pur", "DAWAI PURCHASE", "#2563eb")):
            f = tk.Frame(row, bg="white", highlightbackground="#e2e8f0", highlightthickness=1); f.pack(side="left", expand=True, fill="both", padx=6)
            strip = tk.Frame(f, bg=col, width=6); strip.pack(side="left", fill="y")
            body = tk.Frame(f, bg="white"); body.pack(side="left", padx=14, pady=12)
            t = tk.Label(body, text=title, bg="white", fg="#64748b", font=("Segoe UI", 9, "bold")); t.pack(anchor="w")
            v = tk.Label(body, text="0", bg="white", fg=col, font=("Segoe UI", 24, "bold")); v.pack(anchor="w")
            self.k[key] = (strip, t, v)
        grid = tk.Frame(self, bg=self.BG); grid.pack(fill="x", padx=10, pady=6)
        for title, col, keys in (
            ("Income Breakdown", "#16a34a", ["Medical store sale", "Lab", "OPD fees"]),
            ("Kharcha Breakdown", "#ea580c", ["Bechi dawai ki cost", "Salaries", "Expenses"]),
            ("Stock & Staff", "#0f766e", ["Dawaiyon ki types", "Total units", "Stock ki value", "Kam stock (<10)", "Total employees", "Mahana salary bill"])):
            p = tk.Frame(grid, bg="white", highlightbackground="#e2e8f0", highlightthickness=1); p.pack(side="left", expand=True, fill="both", padx=6, anchor="n")
            tk.Label(p, text=title, bg=col, fg="white", font=("Segoe UI", 11, "bold"), anchor="w", padx=12, pady=7).pack(fill="x")
            for name in keys:
                r = tk.Frame(p, bg="white"); r.pack(fill="x", padx=12, pady=5)
                tk.Label(r, text=name, bg="white", fg="#475569").pack(side="left")
                self.v[name] = tk.Label(r, bg="white", fg="#0f172a", font=("Segoe UI", 10, "bold")); self.v[name].pack(side="right")
        self.cv = tk.Canvas(self, height=110, bg="white", highlightbackground="#e2e8f0", highlightthickness=1)
        self.cv.pack(fill="x", padx=16, pady=8)
        self.preset(30)

    def preset(self, days):
        from datetime import timedelta
        for e, d in ((self.a, date.today() - timedelta(days=days)), (self.b, date.today())):
            e.delete(0, "end"); e.insert(0, str(d))
        self.show()

    def show(self):
        a, b = self.a.get(), self.b.get()
        s = lambda sql: q(sql + " AND date BETWEEN ? AND ?", (a, b))[0][0] or 0
        sale = s("SELECT SUM(qty*price) FROM sales WHERE 1=1"); cogs = s("SELECT SUM(qty*cost) FROM sales WHERE 1=1")
        purch = s("SELECT SUM(qty*buy_price) FROM purchases WHERE 1=1")
        lab, opd = s("SELECT SUM(fee) FROM lab WHERE 1=1"), s("SELECT SUM(fee) FROM opd WHERE 1=1")
        sal, exp = s("SELECT SUM(amount) FROM salaries WHERE 1=1"), s("SELECT SUM(amount) FROM expenses WHERE 1=1")
        income, cost = sale + lab + opd, cogs + sal + exp
        profit = income - cost
        stock = q("SELECT COUNT(*), SUM(qty), SUM(qty*buy_price) FROM medicines")[0]
        low = q("SELECT COUNT(*) FROM medicines WHERE qty<10")[0][0]
        emp = q("SELECT COUNT(*), SUM(salary) FROM employees")[0]
        pc = "#16a34a" if profit >= 0 else "#dc2626"
        self.k["inc"][2].config(text=f"{income:,.0f}"); self.k["cost"][2].config(text=f"{cost:,.0f}"); self.k["pur"][2].config(text=f"{purch:,.0f}")
        self.k["pl"][0].config(bg=pc); self.k["pl"][2].config(text=f"{abs(profit):,.0f}", fg=pc)
        self.k["pl"][1].config(text="PROFIT" if profit >= 0 else "LOSS")
        for k, val in {"Medical store sale": sale, "Lab": lab, "OPD fees": opd, "Bechi dawai ki cost": cogs, "Salaries": sal, "Expenses": exp,
                       "Stock ki value": stock[2] or 0, "Mahana salary bill": emp[1] or 0}.items():
            self.v[k].config(text=f"{val:,.2f}")
        for k, val in {"Dawaiyon ki types": stock[0], "Total units": stock[1] or 0, "Total employees": emp[0], "Kam stock (<10)": low}.items():
            self.v[k].config(text=str(val), fg="#dc2626" if k.startswith("Kam") and low else "#0f172a")
        self.cv.delete("all"); mx = max(income, cost, 1)
        for y, lab_, val, col in ((20, "Income", income, "#16a34a"), (62, "Kharcha", cost, "#ea580c")):
            self.cv.create_text(12, y + 12, text=lab_, anchor="w", font=("Segoe UI", 10, "bold"), fill="#475569")
            self.cv.create_rectangle(90, y, 90 + 700 * val / mx, y + 26, fill=col, width=0)
            self.cv.create_text(90 + 700 * val / mx + 10, y + 13, text=f"{val:,.0f}", anchor="w", font=("Segoe UI", 10, "bold"))

root = tk.Tk(); root.title("Hospital Management System"); root.geometry("1100x700"); root.configure(bg="#f1f5f9")
st = ttk.Style(); st.theme_use("clam")
st.configure(".", font=("Segoe UI", 10), background="#f1f5f9")
st.configure("TNotebook", background="#0f766e", borderwidth=0)
st.configure("TNotebook.Tab", padding=(16, 8), font=("Segoe UI", 10, "bold"), background="#99f6e4", foreground="#134e4a")
st.map("TNotebook.Tab", background=[("selected", "white")], foreground=[("selected", "#0f766e")])
st.configure("Treeview", rowheight=26, fieldbackground="white", font=("Segoe UI", 10))
st.configure("Treeview.Heading", background="#0f766e", foreground="white", font=("Segoe UI", 10, "bold"), padding=6)
st.map("Treeview", background=[("selected", "#5eead4")], foreground=[("selected", "black")])
st.configure("Accent.TButton", background="#16a34a", foreground="white", font=("Segoe UI", 10, "bold"), padding=6)
st.map("Accent.TButton", background=[("active", "#15803d")])
st.configure("Danger.TButton", background="#dc2626", foreground="white", font=("Segoe UI", 10, "bold"), padding=6)
st.map("Danger.TButton", background=[("active", "#b91c1c")])
st.configure("TButton", padding=6)
tk.Label(root, text="  \u271a  HOSPITAL MANAGEMENT SYSTEM", bg="#0f766e", fg="white", font=("Segoe UI", 18, "bold"), anchor="w", pady=10).pack(fill="x")
nb = ttk.Notebook(root); nb.pack(fill="both", expand=True)
dash = Dashboard(nb)
tabs = [
 ("Dashboard / Profit-Loss", dash),
 ("Medicines (Stock)", Crud(nb, "medicines", [("Name","name","txt"),("Company","company","txt"),("Batch","batch","txt"),("Expiry","expiry","txt"),("Buy price","buy_price","num"),("Sale price","sale_price","num"),("Qty","qty","num")],
    "SELECT * FROM medicines ORDER BY name", ("ID","Name","Company","Batch","Expiry","Buy","Sale","Qty"), dated=False, hook=lambda v: v.update(qty=int(v["qty"])))),
 ("Purchase", Crud(nb, "purchases", [("Medicine","medicine_id","med"),("Qty","qty","num"),("Buy price","buy_price","num"),("Supplier","supplier","txt")],
    "SELECT p.id,p.date,m.name,p.qty,p.buy_price,p.supplier FROM purchases p JOIN medicines m ON m.id=p.medicine_id ORDER BY p.id DESC", ("ID","Date","Medicine","Qty","Price","Supplier"), hook=purchase_hook)),
 ("Sale", Crud(nb, "sales", [("Medicine","medicine_id","med"),("Qty","qty","num")],
    "SELECT s.id,s.date,m.name,s.qty,s.price,s.qty*s.price FROM sales s JOIN medicines m ON m.id=s.medicine_id ORDER BY s.id DESC", ("ID","Date","Medicine","Qty","Price","Total"), hook=sale_hook)),
 ("Lab", Crud(nb, "lab", [("Patient","patient","txt"),("Test","test","txt"),("Fee","fee","num")],
    "SELECT id,date,patient,test,fee FROM lab ORDER BY id DESC", ("ID","Date","Patient","Test","Fee"))),
 ("OPD", Crud(nb, "opd", [("Patient","patient","txt"),("Doctor","doctor","txt"),("Fee","fee","num")],
    "SELECT id,date,patient,doctor,fee FROM opd ORDER BY id DESC", ("ID","Date","Patient","Doctor","Fee"))),
 ("Employees", Crud(nb, "employees", [("Name","name","txt"),("Role","role","txt"),("Salary","salary","num"),("Phone","phone","txt")],
    "SELECT * FROM employees", ("ID","Name","Role","Salary","Phone"), dated=False, extra=[("Pay salary (aaj)", pay_salary)])),
 ("Expenses", Crud(nb, "expenses", [("Category","category","txt"),("Amount","amount","num"),("Note","note","txt")],
    "SELECT id,date,category,amount,note FROM expenses ORDER BY id DESC", ("ID","Date","Category","Amount","Note"))),
]
for name, frame in tabs: nb.add(frame, text=name)
def on_tab(_):
    f = nb.nametowidget(nb.select())
    (f.show if isinstance(f, Dashboard) else f.refresh)()
nb.bind("<<NotebookTabChanged>>", on_tab)
root.mainloop()
