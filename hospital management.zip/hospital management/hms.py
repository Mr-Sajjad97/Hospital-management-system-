import sqlite3, tkinter as tk
from tkinter import ttk, messagebox
from datetime import date

db = sqlite3.connect("hms.db")
db.executescript("""
CREATE TABLE IF NOT EXISTS medicines(id INTEGER PRIMARY KEY, name, company, batch, expiry, buy_price REAL, sale_price REAL, qty INTEGER);
CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY, date, medicine_id INTEGER, qty INTEGER, buy_price REAL, supplier);
CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY, date, medicine_id INTEGER, qty INTEGER, price REAL, cost REAL);
CREATE TABLE IF NOT EXISTS lab(id INTEGER PRIMARY KEY, date, patient, test, fee REAL);
CREATE TABLE IF NOT EXISTS opd(id INTEGER PRIMARY KEY, date, patient, doctor, fee REAL);
CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY, name, role, salary REAL, phone);
CREATE TABLE IF NOT EXISTS salaries(id INTEGER PRIMARY KEY, date, employee_id INTEGER, amount REAL);
CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY, date, category, amount REAL, note);
""")

def q(sql, args=()):
    cur = db.execute(sql, args); db.commit(); return cur.fetchall()

def meds():
    return [f"{r[0]} - {r[1]}" for r in q("SELECT id,name FROM medicines ORDER BY name")]

class Crud(ttk.Frame):
    """Generic tab: form on top, list below. fields = (label, column, kind) kind: txt/num/med"""
    def __init__(self, parent, table, fields, select, heads, hook=None, dated=True, extra=None):
        super().__init__(parent)
        self.table, self.fields, self.select, self.hook, self.dated = table, fields, select, hook, dated
        form = ttk.Frame(self); form.pack(fill="x", padx=8, pady=8)
        self.w = {}
        for i, (lab, col, kind) in enumerate(fields):
            ttk.Label(form, text=lab).grid(row=i // 4 * 2, column=i % 4, sticky="w", padx=4)
            if kind == "med":
                e = ttk.Combobox(form, width=22, postcommand=lambda: self.w_med.config(values=meds()))
                self.w_med = e
            else:
                e = ttk.Entry(form, width=22)
            e.grid(row=i // 4 * 2 + 1, column=i % 4, padx=4, pady=2)
            self.w[col] = (e, kind)
        bar = ttk.Frame(self); bar.pack(fill="x", padx=8)
        ttk.Button(bar, text="Add", style="Accent.TButton", command=self.add).pack(side="left", padx=4)
        ttk.Button(bar, text="Delete selected", style="Danger.TButton", command=self.delete).pack(side="left", padx=4)
        for text, fn in (extra or []):
            ttk.Button(bar, text=text, command=lambda f=fn: f(self.selected())).pack(side="left", padx=4)
        self.tree = ttk.Treeview(self, columns=heads, show="headings")
        for h in heads:
            self.tree.heading(h, text=h); self.tree.column(h, width=110)
        self.tree.tag_configure("low", background="#fecaca")
        self.tree.tag_configure("odd", background="#f0fdfa")
        self.tree.pack(fill="both", expand=True, padx=8, pady=8)
        self.refresh()

    def selected(self):
        s = self.tree.selection()
        return self.tree.item(s[0])["values"] if s else None

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(q(self.select)):
            tag = "low" if self.table == "medicines" and r[-1] < 10 else "odd" if i % 2 else ""
            self.tree.insert("", "end", values=r, tags=(tag,))

    def add(self):
        vals = {}
        try:
            for col, (e, kind) in self.w.items():
                v = e.get().strip()
                if not v: raise ValueError("Sab fields bharo")
                vals[col] = float(v) if kind == "num" else int(v.split(" - ")[0]) if kind == "med" else v
            if self.hook: self.hook(vals)
            if self.dated: vals["date"] = str(date.today())
            q(f"INSERT INTO {self.table}({','.join(vals)}) VALUES({','.join('?' * len(vals))})", list(vals.values()))
        except ValueError as ex:
            return messagebox.showerror("Error", str(ex) if "Sab" in str(ex) or "stock" in str(ex).lower() else "Number sahi likho")
        for e, _ in self.w.values(): e.delete(0, "end")
        self.refresh()

    def delete(self):
        r = self.selected()
        if r and messagebox.askyesno("Delete", "Pakka delete karna hai?"):
            q(f"DELETE FROM {self.table} WHERE id=?", (r[0],)); self.refresh()

def purchase_hook(v):
    v["qty"] = int(v["qty"])
    q("UPDATE medicines SET qty=qty+?, buy_price=? WHERE id=?", (v["qty"], v["buy_price"], v["medicine_id"]))

def sale_hook(v):
    v["qty"] = int(v["qty"])
    m = q("SELECT qty,sale_price,buy_price FROM medicines WHERE id=?", (v["medicine_id"],))[0]
    if v["qty"] > m[0]: raise ValueError(f"Stock kam hai, sirf {m[0]} bache hain")
    v["price"], v["cost"] = m[1], m[2]
    q("UPDATE medicines SET qty=qty-? WHERE id=?", (v["qty"], v["medicine_id"]))

def pay_salary(row):
    if row and messagebox.askyesno("Salary", f"{row[1]} ko {row[3]} salary dena hai?"):
        q("INSERT INTO salaries(date,employee_id,amount) VALUES(?,?,?)", (str(date.today()), row[0], row[3]))
        messagebox.showinfo("Done", "Salary likh li gayi")

class Dashboard(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        top = ttk.Frame(self); top.pack(pady=10)
        self.a, self.b = ttk.Entry(top, width=12), ttk.Entry(top, width=12)
        self.a.insert(0, date.today().replace(day=1).isoformat()); self.b.insert(0, str(date.today()))
        for t, w in (("From (YYYY-MM-DD)", self.a), ("To", self.b)):
            ttk.Label(top, text=t).pack(side="left", padx=4); w.pack(side="left")
        ttk.Button(top, text="Show report", command=self.show).pack(side="left", padx=8)
        cards = ttk.Frame(self); cards.pack(fill="x", padx=10, pady=6)
        self.c = {}
        for key, title, col in (("inc", "TOTAL INCOME", "#16a34a"), ("cost", "TOTAL KHARCHA", "#ea580c"), ("pl", "PROFIT", "#2563eb")):
            f = tk.Frame(cards, bg=col); f.pack(side="left", expand=True, fill="both", padx=6)
            t = tk.Label(f, text=title, bg=col, fg="white", font=("Segoe UI", 11, "bold")); t.pack(pady=(12, 0))
            v = tk.Label(f, text="0", bg=col, fg="white", font=("Segoe UI", 26, "bold")); v.pack(pady=(0, 12))
            self.c[key] = (f, t, v)
        self.out = tk.Text(self, font=("Consolas", 11), height=20, state="disabled", bg="white", relief="flat"); self.out.pack(fill="both", expand=True, padx=10)
        self.show()

    def show(self):
        a, b = self.a.get(), self.b.get()
        s = lambda sql: q(sql + " AND date BETWEEN ? AND ?", (a, b))[0][0] or 0
        sale = s("SELECT SUM(qty*price) FROM sales WHERE 1=1"); cogs = s("SELECT SUM(qty*cost) FROM sales WHERE 1=1")
        purch = s("SELECT SUM(qty*buy_price) FROM purchases WHERE 1=1")
        lab, opd = s("SELECT SUM(fee) FROM lab WHERE 1=1"), s("SELECT SUM(fee) FROM opd WHERE 1=1")
        sal, exp = s("SELECT SUM(amount) FROM salaries WHERE 1=1"), s("SELECT SUM(amount) FROM expenses WHERE 1=1")
        income, cost = sale + lab + opd, cogs + sal + exp
        profit = income - cost
        self.c["inc"][2].config(text=f"{income:,.0f}"); self.c["cost"][2].config(text=f"{cost:,.0f}")
        pc = "#16a34a" if profit >= 0 else "#dc2626"
        for w in self.c["pl"]: w.config(bg=pc)
        self.c["pl"][1].config(text="PROFIT" if profit >= 0 else "LOSS"); self.c["pl"][2].config(text=f"{abs(profit):,.0f}")
        stock = q("SELECT COUNT(*), SUM(qty), SUM(qty*buy_price) FROM medicines")[0]
        low = q("SELECT COUNT(*) FROM medicines WHERE qty<10")[0][0]
        emp = q("SELECT COUNT(*), SUM(salary) FROM employees")[0]
        txt = f"""REPORT: {a}  se  {b}
{'=' * 44}
INCOME
  Medical store sale : {sale:12,.2f}
  Lab                : {lab:12,.2f}
  OPD fees           : {opd:12,.2f}
  Total income       : {income:12,.2f}

KHARCHA
  Bechi hui dawai ki cost : {cogs:12,.2f}
  Salaries                : {sal:12,.2f}
  Expenses                : {exp:12,.2f}
  Total kharcha           : {cost:12,.2f}

{'PROFIT' if profit >= 0 else 'LOSS'}: {abs(profit):,.2f}
(Is muddat mein dawai purchase: {purch:,.2f})

STOCK
  Medicines ki types : {stock[0]}
  Total units        : {stock[1] or 0}
  Stock ki value     : {(stock[2] or 0):,.2f}
  Kam stock (<10)    : {low}

EMPLOYEES
  Total employees    : {emp[0]}
  Mahana salary bill : {(emp[1] or 0):,.2f}
"""
        self.out.config(state="normal"); self.out.delete("1.0", "end"); self.out.insert("end", txt); self.out.config(state="disabled")

root = tk.Tk(); root.title("Hospital Management System"); root.geometry("1100x700"); root.configure(bg="#f1f5f9")
st = ttk.Style(); st.theme_use("clam")
st.configure(".", font=("Segoe UI", 10), background="#f1f5f9")
st.configure("TNotebook", background="#0f766e", borderwidth=0)
st.configure("TNotebook.Tab", padding=(16, 8), font=("Segoe UI", 10, "bold"), background="#99f6e4", foreground="#134e4a")
st.map("TNotebook.Tab", background=[("selected", "white")], foreground=[("selected", "#0f766e")])
st.configure("Treeview", rowheight=26, fieldbackground="white", font=("Segoe UI", 10))
st.configure("Treeview.Heading", background="#0f766e", foreground="white", font=("Segoe UI", 10, "bold"), padding=6)
st.map("Treeview", background=[("selected", "#5eead4")], foreground=[("selected", "black")])
st.configure("Accent.TButton", background="#16a34a", foreground="white", font=("Segoe UI", 10, "bold"), padding=6)
st.map("Accent.TButton", background=[("active", "#15803d")])
st.configure("Danger.TButton", background="#dc2626", foreground="white", font=("Segoe UI", 10, "bold"), padding=6)
st.map("Danger.TButton", background=[("active", "#b91c1c")])
st.configure("TButton", padding=6)
tk.Label(root, text="  \u271a  HOSPITAL MANAGEMENT SYSTEM", bg="#0f766e", fg="white", font=("Segoe UI", 18, "bold"), anchor="w", pady=10).pack(fill="x")
nb = ttk.Notebook(root); nb.pack(fill="both", expand=True)
dash = Dashboard(nb)
tabs = [
 ("Dashboard / Profit-Loss", dash),
 ("Medicines (Stock)", Crud(nb, "medicines", [("Name","name","txt"),("Company","company","txt"),("Batch","batch","txt"),("Expiry","expiry","txt"),("Buy price","buy_price","num"),("Sale price","sale_price","num"),("Qty","qty","num")],
    "SELECT * FROM medicines ORDER BY name", ("ID","Name","Company","Batch","Expiry","Buy","Sale","Qty"), dated=False, hook=lambda v: v.update(qty=int(v["qty"])))),
 ("Purchase", Crud(nb, "purchases", [("Medicine","medicine_id","med"),("Qty","qty","num"),("Buy price","buy_price","num"),("Supplier","supplier","txt")],
    "SELECT p.id,p.date,m.name,p.qty,p.buy_price,p.supplier FROM purchases p JOIN medicines m ON m.id=p.medicine_id ORDER BY p.id DESC", ("ID","Date","Medicine","Qty","Price","Supplier"), hook=purchase_hook)),
 ("Sale", Crud(nb, "sales", [("Medicine","medicine_id","med"),("Qty","qty","num")],
    "SELECT s.id,s.date,m.name,s.qty,s.price,s.qty*s.price FROM sales s JOIN medicines m ON m.id=s.medicine_id ORDER BY s.id DESC", ("ID","Date","Medicine","Qty","Price","Total"), hook=sale_hook)),
 ("Lab", Crud(nb, "lab", [("Patient","patient","txt"),("Test","test","txt"),("Fee","fee","num")],
    "SELECT id,date,patient,test,fee FROM lab ORDER BY id DESC", ("ID","Date","Patient","Test","Fee"))),
 ("OPD", Crud(nb, "opd", [("Patient","patient","txt"),("Doctor","doctor","txt"),("Fee","fee","num")],
    "SELECT id,date,patient,doctor,fee FROM opd ORDER BY id DESC", ("ID","Date","Patient","Doctor","Fee"))),
 ("Employees", Crud(nb, "employees", [("Name","name","txt"),("Role","role","txt"),("Salary","salary","num"),("Phone","phone","txt")],
    "SELECT * FROM employees", ("ID","Name","Role","Salary","Phone"), dated=False, extra=[("Pay salary (aaj)", pay_salary)])),
 ("Expenses", Crud(nb, "expenses", [("Category","category","txt"),("Amount","amount","num"),("Note","note","txt")],
    "SELECT id,date,category,amount,note FROM expenses ORDER BY id DESC", ("ID","Date","Category","Amount","Note"))),
]
for name, frame in tabs: nb.add(frame, text=name)
def on_tab(_):
    f = nb.nametowidget(nb.select())
    (f.show if isinstance(f, Dashboard) else f.refresh)()
nb.bind("<<NotebookTabChanged>>", on_tab)
root.mainloop()
