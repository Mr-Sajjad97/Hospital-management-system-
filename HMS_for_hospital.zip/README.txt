HMS - Hospital Management System (VS Code Project)
===================================================

FEATURES
--------
Desktop management for medicine stock, purchases, supplier payments, sales and
receipts, laboratory fees, OPD fees, employees, salaries, expenses, dashboards,
date filters, search, PIN/recovery login, database import/restore, and automatic
backups. HMS runs locally on this computer; it does not provide phone or LAN
access.

FILES
-----
hms_main.py       Desktop application
requirements.txt  Python packages
run_hms.bat       Create a virtual environment and start HMS on Windows
build_hms.bat     Build a portable Windows application
.vscode/          VS Code launch configuration

RUN IN VS CODE (WINDOWS)
------------------------
1. Install Python 3.10 or newer from python.org. During installation, enable
   "Add python.exe to PATH". Install the Python extension in VS Code.
2. Extract the whole project folder, then open that folder in VS Code.
3. Open Terminal > New Terminal and run:
       py -3 -m venv .venv
       .venv\Scripts\activate
       python -m pip install --upgrade pip
       pip install -r requirements.txt
       python hms_main.py
   Or double-click run_hms.bat; it creates the virtual environment and installs
   the requirements for you.
4. To debug in VS Code, select the .venv Python interpreter and press F5.

DATA AND BACKUPS
----------------
On first start, HMS creates HMS_Data\hms.db and HMS_Data\backups beside the
application. If that location is not writable, data is stored under
%LOCALAPPDATA%\HMS\HMS_Data. Daily and on-close backups are automatic.
Use "Backup / Restore" in the app for a manual backup or safe database import.
Keep a separate copy of HMS_Data; it contains sensitive patient and business
records. Do not share it or commit it to Git.

OLD DATABASE
------------
Put your old hms.db beside hms_main.py before the first launch for automatic
import, or use Backup / Restore > Import Old Data. Import replaces current
business records, so HMS first creates a safety backup. Your current PIN stays.

BUILD A PORTABLE WINDOWS APP
----------------------------
Double-click build_hms.bat. It installs the listed packages and creates
dist\HMS\HMS.exe and dist\HMS_for_hospital.zip. Keep the complete dist\HMS
folder together. Rebuilding keeps the existing dist\HMS\HMS_Data folder. An
application icon is optional; if you add hms.ico beside hms_main.py, the
builder includes it.

SHARE HMS WITH ANOTHER HOSPITAL
-------------------------------
There is no central signup service or hospital-count limit: each hospital can
have its own HMS installation and database. Each database supports one Admin
account. On the first run with a new, empty database, the hospital creates its
Admin PIN and recovery details using Sign Up, then uses Sign In on later runs.

To share a built app, send dist\HMS_for_hospital.zip. The builder excludes
HMS_Data from this ZIP, so it does not contain your records or account.
The hospital should extract the ZIP to its own folder, keep HMS.exe and
_internal together, and run HMS.exe. The first run creates that hospital's
own fresh HMS_Data database and offers Sign Up for its Admin. Never distribute
your own dist\HMS\HMS_Data folder. Keep it for your own continued use.

NOTES
-----
- The desktop interface requires Windows/macOS/Linux with Python Tk support;
  the supplied one-click packaging scripts target Windows.
- SQLite and all records remain on the local computer. There is no cloud sync.
- HMS is a desktop-only application and does not start a network/mobile server.
- Before using HMS for real clinical or financial operations, verify the
  calculations, workflows, backups, and local legal/privacy requirements for
  your clinic. This software does not provide a compliance certification.